export * from './school-class.repository';
export * from './access-role.repository';
export * from './class-profile.repository';
export * from './post-type.repository';
export * from './post.repository';
export * from './registration-link.repository';
export * from './user-profile.repository';
